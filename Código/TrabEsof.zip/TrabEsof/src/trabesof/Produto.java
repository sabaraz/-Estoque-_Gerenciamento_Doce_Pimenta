package trabesof;

public class Produto {
    String nome;
    double precoVenda;
    double precoCusto;
    int estoque;

    
    public Produto(String nome, double precoVenda, double precoCusto, int estoque) {
        this.nome = nome;
        this.precoVenda = precoVenda;
        this.precoCusto = precoCusto;
        this.estoque = estoque;
    }
}
