package trabesof;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class TrabEsof {

    static Scanner scanner = new Scanner(System.in);
    static Map<String, Produto> produtos = new HashMap<>();
    static List<Venda> vendas = new ArrayList<>();
    
    public static void main(String[] args) {
        
        while (true) {
            System.out.println("\n1. Cadastrar Produto");
            System.out.println("2. Realizar Venda");
            System.out.println("3. Preencher Estoque");
            System.out.println("4. Gerar Relatório");
            System.out.println("5. Sair");
            System.out.print("Escolha uma opção: ");
            String opcao = scanner.nextLine();

            switch (opcao) {
                case "1":
                    cadastrarProduto();
                    break;
                case "2":
                    realizarVenda();
                    break;
                case "3":
                    preencherEstoque();
                    break;
                case "4":
                    gerarRelatorio();
                    break;
                case "5":
                    System.out.println("Saindo...");
                    return;
                default:
                    System.out.println("Opção inválida!");
            }
        }
    }

    static void cadastrarProduto() {
        System.out.print("Código do produto: ");
        String codigo = scanner.nextLine();
        System.out.print("Nome do produto: ");
        String nome = scanner.nextLine();
        System.out.print("Preço de venda: ");
        double precoVenda = Double.parseDouble(scanner.nextLine());
        System.out.print("Preço de custo: ");
        double precoCusto = Double.parseDouble(scanner.nextLine());
        System.out.print("Quantidade em estoque: ");
        int estoque = Integer.parseInt(scanner.nextLine());

        produtos.put(codigo, new Produto(nome, precoVenda, precoCusto, estoque));
    }

    static void realizarVenda() {
        System.out.print("Código do produto: ");
        String codigo = scanner.nextLine();
        Produto produto = produtos.get(codigo);

        if (produto != null) {
            System.out.print("Quantidade vendida: ");
            int quantidade = Integer.parseInt(scanner.nextLine());

            if (produto.estoque >= quantidade) {
                produto.estoque -= quantidade;
                vendas.add(new Venda(codigo, quantidade, produto.precoVenda, produto.precoCusto));
                System.out.println("Venda realizada com sucesso!");
            } else {
                System.out.println("Estoque insuficiente!");
            }
        } else {
            System.out.println("Produto não encontrado!");
        }
    }

    static void preencherEstoque() {
        System.out.print("Código do produto: ");
        String codigo = scanner.nextLine();
        Produto produto = produtos.get(codigo);
        if (produto != null) {
            System.out.print("Quantidade a adicionar: ");
            int quantidade = Integer.parseInt(scanner.nextLine());
            produto.estoque += quantidade;
            System.out.println("Estoque atualizado com sucesso!");
        } else {
            System.out.println("Produto não encontrado!");
        }
    }

    static void gerarRelatorio() {
        double totalReceita = 0;
        double totalCusto = 0;

        System.out.println("\nRelatório de Vendas:");

        for (Venda venda : vendas) {
            Produto produto = produtos.get(venda.codigo);
            double receita = venda.quantidade * venda.precoVenda;
            double custo = venda.quantidade * venda.precoCusto;
            double lucro = receita - custo;

            totalReceita += receita;
            totalCusto += custo;

            System.out.printf("Produto: %s | Quantidade: %d | Receita: R$%.2f | Lucro: R$%.2f%n",
                    produto.nome, venda.quantidade, receita, lucro);
        }

        System.out.printf("\nTotal de Vendas: R$%.2f%n", totalReceita);
        System.out.printf("Lucro Total: R$%.2f%n", totalReceita - totalCusto);

        if (totalCusto > totalReceita) {
            System.out.printf("Prejuízo Total: R$%.2f%n", totalCusto - totalReceita);
        }
    }
}
