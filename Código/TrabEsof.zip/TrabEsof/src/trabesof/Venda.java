package trabesof;

public class Venda {
    String codigo;
    int quantidade;
    double precoVenda;
    double precoCusto;


    public Venda(String codigo, int quantidade, double precoVenda, double precoCusto) {
        this.codigo = codigo;
        this.quantidade = quantidade;
        this.precoVenda = precoVenda;
        this.precoCusto = precoCusto;
    }
}
